
# DENTIQUE Dental Clinic — Premium Futuristic Website

A luxury, futuristic, fully responsive marketing site for DENTIQUE Dental Clinic & Implant Center (Lucknow). Apple-level polish, glassmorphism, neon purple/cyan palette, 3D tooth in hero, cinematic scroll animations, and conversion-focused booking flow.

## Scope & Approach

Built on the existing TanStack Start + React 19 + Tailwind v4 + shadcn stack (Next.js is not supported here — we'll match the requested feel using the available stack, which produces the same visual result). Multi-route architecture for SEO (each section that benefits from a standalone URL gets its own route), with the homepage acting as a cinematic single-scroll experience that includes all key sections.

Libraries to add:
- `framer-motion` — entrance, hover, parallax, page transitions
- `@react-three/fiber` + `@react-three/drei` + `three` — 3D floating tooth & implant in hero
- `lenis` — smooth scrolling
- `embla-carousel-react` (already in shadcn) — testimonials
- `lucide-react` (already present) — icons

## Route Structure

```
src/routes/
  __root.tsx           navbar + footer shell, Lenis smooth scroll, cursor glow, scroll progress
  index.tsx            cinematic homepage (all sections below)
  services.tsx         full services grid + details
  about.tsx            clinic story, timeline, team
  gallery.tsx          before/after smile transformations
  contact.tsx          map, contact card, booking form
```

Each route gets unique `head()` meta (title, description, og:title, og:description) targeting the requested SEO keywords.

## Design System (src/styles.css)

Define semantic OKLCH tokens:
- `--background` pure white / deep night for dark sections
- `--primary` neon purple `#8B5CF6`
- `--accent` cyan `#7DD3FC`
- `--gradient-primary` purple→cyan
- `--gradient-aurora` multi-stop animated aurora
- `--glass-bg`, `--glass-border` for glassmorphism
- `--glow-primary`, `--shadow-elegant`, `--shadow-neon`
- Custom keyframes: `aurora`, `float`, `blob`, `shimmer`, `grain`, `pulse-glow`, `streak`

Fonts: load Poppins + Clash Display (Satoshi/General Sans are not freely on Google Fonts) via `<link>` in `__root.tsx` head.

All component colors use semantic tokens — no hardcoded hex in JSX.

## Homepage Sections

1. **Loader** — full-screen logo reveal with neon ring, fades out on mount.
2. **Sticky Navbar** — translucent, blurs on scroll, animated hamburger on mobile, magnetic CTA "Book Now".
3. **Hero** — fullscreen aurora gradient + animated blobs + grain overlay; 3D floating/rotating tooth (R3F) on the right; bold headline "Luxury Dental Care With Futuristic Precision"; dual CTAs; three floating glass stat cards (Happy Patients, Years of Experience, Successful Implants); animated scroll indicator.
4. **Services** — 6 glassmorphism tilt cards (Dental Implants, Teeth Whitening, Cosmetic Dentistry, Smile Makeovers, Dental Check-ups, Bonding) with neon glow on hover.
5. **About / Story** — split layout, AI-generated clinic interior, animated vertical timeline, floating experience badges.
6. **Why Choose Us** — 6 interactive cards with animated counters and glowing icons.
7. **Before & After** — draggable slider comparison component for smile transformations.
8. **Testimonials** — autoplay Embla carousel with glowing review cards and star ratings.
9. **Booking Form** — multi-step glass form (Service → Date/Time → Details), focus-glow inputs, submit shows success toast (no backend; mailto/WhatsApp fallback).
10. **Contact / Location** — embedded Google Maps iframe styled in a glass frame, contact card with address/phone/hours, floating "Get Directions" button.
11. **FAQ** — shadcn Accordion with smooth reveals.
12. **Footer** — minimal, animated logo glow, social icons with hover glow.

Floating global elements: WhatsApp quick-connect button, scroll-progress bar at top, cursor glow follower (desktop only).

## AI-Generated Imagery

Generate to `src/assets/` (premium tier for hero / cover):
- `hero-patient.jpg` — luxury smiling patient portrait
- `clinic-interior.jpg` — modern dental clinic interior
- `doctor-portrait.jpg` — doctor in premium uniform
- `implant-closeup.jpg` — dental implant macro
- `before-1.jpg` / `after-1.jpg`, `before-2.jpg` / `after-2.jpg` — smile transformations
- `og-cover.jpg` — 1920×1080 social share

## SEO

- Per-route `head()` with targeted titles/descriptions: "Best Dental Clinic in Lucknow", "Dental Implants Vrindavan Yojna", "Cosmetic Dentistry Lucknow", "Teeth Whitening Lucknow".
- JSON-LD `Dentist` schema on the home route with NAP (name, address, phone), opening hours, geo.
- Single H1 per page, semantic landmarks, alt text on all images.
- og:image set on each route from the relevant hero image.

## Technical Notes

- 3D scene wrapped in `Suspense` + `<ClientOnly>` guard (dynamic import) to avoid SSR `window` crashes.
- Lenis initialized in `__root.tsx` inside a `useEffect` (client-only).
- Framer Motion `whileInView` for scroll-triggered reveals; `prefers-reduced-motion` respected.
- Mobile-first; 3D model swapped for static glow image below `md` to keep performance high.
- No backend in this pass — booking submits go to a `mailto:` + WhatsApp deep link (`https://wa.me/919975764714`). Lovable Cloud can be added later if the user wants persisted bookings.

## Out of Scope (this pass)

- Real backend booking persistence, AI chatbot, exit-intent popup logic — can be added in a follow-up with Lovable Cloud + Lovable AI.
- Custom Satoshi/General Sans (licensed) — using Clash Display + Poppins as the closest free premium pair.

## Deliverable

A polished, fully responsive multi-page site matching the brief, ready to publish. Booking and WhatsApp CTAs wired to the provided phone number `+91 99757 64714`.
