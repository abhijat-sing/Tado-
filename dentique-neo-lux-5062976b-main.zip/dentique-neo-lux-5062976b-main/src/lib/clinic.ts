export const CLINIC = {
  name: "DENTIQUE Dental Clinic & Implant Center",
  shortName: "DENTIQUE",
  phone: "+91 99757 64714",
  phoneRaw: "+919975764714",
  whatsapp: "https://wa.me/919975764714",
  email: "hello@dentique.in",
  address:
    "Behind SKD School, Vrindavan Yojna-2, Sector 2, Kalandi Park, Vrindavan Colony, Lucknow, Uttar Pradesh 226014",
  city: "Lucknow",
  region: "Uttar Pradesh",
  postal: "226014",
  country: "IN",
  mapsEmbed:
    "https://www.google.com/maps?q=Vrindavan+Yojna+Sector+2+Kalandi+Park+Lucknow&output=embed",
  mapsLink:
    "https://www.google.com/maps/search/?api=1&query=DENTIQUE+Dental+Clinic+Vrindavan+Yojna+Lucknow",
  services: [
    "Dental Implants",
    "Teeth Whitening",
    "Cosmetic Dentistry",
    "Smile Makeovers",
    "Dental Check-ups",
    "Dental Bonding",
  ],
};
