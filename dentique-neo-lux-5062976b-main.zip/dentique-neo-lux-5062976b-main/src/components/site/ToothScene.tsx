import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Environment, MeshDistortMaterial } from "@react-three/drei";
import { Suspense, useRef } from "react";
import type { Mesh } from "three";

function ToothModel() {
  const ref = useRef<Mesh>(null);
  useFrame((_, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * 0.35;
      ref.current.rotation.x += delta * 0.08;
    }
  });
  // Stylized "tooth" — two stacked rounded shapes (premium abstract look)
  return (
    <group>
      <Float speed={1.6} rotationIntensity={0.4} floatIntensity={1.2}>
        <mesh ref={ref} position={[0, 0.2, 0]} castShadow>
          <sphereGeometry args={[1.05, 64, 64]} />
          <MeshDistortMaterial
            color="#ffffff"
            distort={0.18}
            speed={1.4}
            roughness={0.05}
            metalness={0.35}
            emissive="#8B5CF6"
            emissiveIntensity={0.25}
          />
        </mesh>
        <mesh position={[0, -0.95, 0]}>
          <cylinderGeometry args={[0.35, 0.55, 0.9, 32]} />
          <meshStandardMaterial
            color="#7DD3FC"
            metalness={0.7}
            roughness={0.18}
            emissive="#7DD3FC"
            emissiveIntensity={0.25}
          />
        </mesh>
      </Float>
      <Float speed={1} rotationIntensity={0.5} floatIntensity={2}>
        <mesh position={[1.6, 0.6, -0.4]}>
          <icosahedronGeometry args={[0.18, 0]} />
          <meshStandardMaterial color="#8B5CF6" emissive="#8B5CF6" emissiveIntensity={1.4} />
        </mesh>
      </Float>
      <Float speed={1.4} rotationIntensity={0.3} floatIntensity={1.5}>
        <mesh position={[-1.4, -0.3, 0.4]}>
          <icosahedronGeometry args={[0.12, 0]} />
          <meshStandardMaterial color="#7DD3FC" emissive="#7DD3FC" emissiveIntensity={1.6} />
        </mesh>
      </Float>
    </group>
  );
}

export function ToothScene() {
  return (
    <Canvas
      camera={{ position: [0, 0, 4.2], fov: 45 }}
      dpr={[1, 1.6]}
      gl={{ antialias: true, alpha: true }}
      style={{ background: "transparent" }}
    >
      <ambientLight intensity={0.6} />
      <directionalLight position={[3, 4, 5]} intensity={1.4} color="#8B5CF6" />
      <directionalLight position={[-4, -2, 3]} intensity={1.1} color="#7DD3FC" />
      <pointLight position={[0, 0, 3]} intensity={1} color="#ffffff" />
      <Suspense fallback={null}>
        <ToothModel />
        <Environment preset="studio" />
      </Suspense>
    </Canvas>
  );
}
