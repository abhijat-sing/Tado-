import { Link } from "@tanstack/react-router";
import { Sparkles, Phone, MapPin, Clock, Instagram, Facebook, Mail } from "lucide-react";
import { CLINIC } from "@/lib/clinic";

export function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden border-t border-border bg-secondary/40">
      <div className="blob -left-20 top-0 h-72 w-72 bg-primary/30" />
      <div className="blob -right-10 bottom-0 h-72 w-72 bg-accent/40" />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-4 py-16 md:grid-cols-4">
        <div className="space-y-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="relative grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground shadow-neon">
              <Sparkles className="h-4 w-4" />
            </span>
            <span className="font-display text-xl font-semibold">DENTIQUE</span>
          </Link>
          <p className="max-w-xs text-sm text-muted-foreground">
            Luxury dental care with futuristic precision. Implants, cosmetic dentistry & smile design in Lucknow.
          </p>
          <div className="flex gap-3">
            {[Instagram, Facebook, Mail].map((Icon, i) => (
              <a
                key={i}
                href="#"
                aria-label="social"
                className="grid h-10 w-10 place-items-center rounded-full border border-border bg-background transition hover:shadow-neon"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Explore
          </h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="hover:text-primary">Home</Link></li>
            <li><Link to="/services" className="hover:text-primary">Services</Link></li>
            <li><Link to="/about" className="hover:text-primary">About</Link></li>
            <li><Link to="/gallery" className="hover:text-primary">Smile Gallery</Link></li>
            <li><Link to="/contact" className="hover:text-primary">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Treatments
          </h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>Dental Implants</li>
            <li>Teeth Whitening</li>
            <li>Cosmetic Dentistry</li>
            <li>Smile Makeovers</li>
            <li>Dental Bonding</li>
            <li>Dental Check-ups</li>
          </ul>
        </div>

        <div className="space-y-3 text-sm">
          <h4 className="mb-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Visit Us
          </h4>
          <p className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 text-primary" /><span>{CLINIC.address}</span></p>
          <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary" /><a href={`tel:${CLINIC.phoneRaw}`} className="hover:text-primary">{CLINIC.phone}</a></p>
          <p className="flex items-start gap-2"><Clock className="mt-0.5 h-4 w-4 text-primary" /><span>Mon–Sat: 10:00 – 21:00<br />Sunday: By appointment</span></p>
        </div>
      </div>
      <div className="relative border-t border-border py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} DENTIQUE Dental Clinic & Implant Center. All rights reserved.
      </div>
    </footer>
  );
}
