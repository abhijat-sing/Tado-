import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ClientOnly } from "@/components/site/ClientOnly";
import { ToothScene } from "@/components/site/ToothScene";
import heroPatient from "@/assets/hero-patient.jpg";

const stats = [
  { v: "12k+", l: "Happy Patients" },
  { v: "15+", l: "Years of Experience" },
  { v: "3500+", l: "Successful Implants" },
];

export function Hero() {
  return (
    <section className="relative grain min-h-[100svh] overflow-hidden pt-28">
      {/* Aurora background */}
      <div aria-hidden className="absolute inset-0 bg-gradient-hero" />
      <div aria-hidden className="absolute inset-0 bg-aurora opacity-60" />
      <div className="blob left-[-6rem] top-20 h-80 w-80 bg-primary/40" />
      <div className="blob right-[-4rem] top-40 h-96 w-96 bg-accent/50" />
      <div className="streak top-1/3" />
      <div className="streak top-2/3" style={{ animationDelay: "-4s" }} />

      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 pb-24 pt-10 md:grid-cols-2 md:items-center md:pt-16">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-border glass px-3 py-1 text-xs font-medium"
          >
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Lucknow's Premium Implant Center
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="mt-5 font-display text-4xl font-semibold leading-[1.05] sm:text-5xl md:text-6xl lg:text-7xl"
          >
            Luxury Dental Care
            <br />
            With{" "}
            <span className="text-gradient">Futuristic Precision</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.25 }}
            className="mt-5 max-w-lg text-base text-muted-foreground sm:text-lg"
          >
            Advanced dental implants, cosmetic dentistry and smile design — delivered in a calming, technology-forward studio in Vrindavan Yojna, Lucknow.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            <Button asChild size="lg" className="magnetic-btn rounded-full bg-gradient-primary text-primary-foreground shadow-neon hover:opacity-95">
              <Link to="/contact">
                Book Appointment <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="magnetic-btn rounded-full border-border/80 bg-background/60 backdrop-blur">
              <Link to="/services">Explore Services</Link>
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.55 }}
            className="mt-10 grid max-w-md grid-cols-3 gap-3"
          >
            {stats.map((s) => (
              <div
                key={s.l}
                className="glass rounded-2xl p-4 text-center shadow-soft"
              >
                <div className="font-display text-xl font-semibold text-gradient sm:text-2xl">
                  {s.v}
                </div>
                <div className="mt-1 text-[11px] text-muted-foreground sm:text-xs">{s.l}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Right visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative mx-auto h-[420px] w-full max-w-md md:h-[560px]"
        >
          <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-primary opacity-25 blur-3xl" />
          <div className="absolute inset-0 overflow-hidden rounded-[2.5rem] glass shadow-neon">
            <img
              src={heroPatient}
              alt="Smiling patient at DENTIQUE Dental Clinic"
              className="h-full w-full object-cover opacity-90"
              fetchPriority="high"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
          </div>
          {/* 3D tooth overlay */}
          <div className="pointer-events-none absolute -right-6 -top-6 h-56 w-56 md:h-72 md:w-72">
            <ClientOnly>
              <ToothScene />
            </ClientOnly>
          </div>

          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -left-4 bottom-10 hidden glass rounded-2xl p-3 shadow-soft md:block"
          >
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-semibold">Painless implants</div>
                <div className="text-[11px] text-muted-foreground">Same-day procedures</div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-muted-foreground">
        <motion.div
          animate={{ y: [0, 8, 0], opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center gap-1 text-[11px]"
        >
          Scroll
          <ChevronDown className="h-4 w-4" />
        </motion.div>
      </div>
    </section>
  );
}
