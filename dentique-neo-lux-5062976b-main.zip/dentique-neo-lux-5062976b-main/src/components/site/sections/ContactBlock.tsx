import { Reveal } from "@/components/site/Reveal";
import { CLINIC } from "@/lib/clinic";
import { MapPin, Phone, Clock, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ContactBlock() {
  return (
    <section id="contact" className="relative py-24">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 lg:grid-cols-5">
        <Reveal className="lg:col-span-3">
          <div className="relative overflow-hidden rounded-[2rem] glass shadow-elegant">
            <iframe
              title="DENTIQUE clinic location"
              src={CLINIC.mapsEmbed}
              className="h-[420px] w-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
            <a
              href={CLINIC.mapsLink}
              target="_blank"
              rel="noreferrer"
              className="absolute bottom-4 right-4 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-neon"
            >
              <Navigation className="h-4 w-4" /> Get directions
            </a>
          </div>
        </Reveal>

        <Reveal delay={0.1} className="lg:col-span-2">
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">Visit Us</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">
            Find us in <span className="text-gradient">Vrindavan Yojna</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Walk in or schedule ahead — our team is ready to welcome you.
          </p>

          <div className="mt-6 space-y-3 text-sm">
            <div className="glass flex items-start gap-3 rounded-2xl p-4">
              <MapPin className="mt-0.5 h-5 w-5 text-primary" />
              <span>{CLINIC.address}</span>
            </div>
            <a href={`tel:${CLINIC.phoneRaw}`} className="glass flex items-center gap-3 rounded-2xl p-4">
              <Phone className="h-5 w-5 text-primary" />
              {CLINIC.phone}
            </a>
            <div className="glass flex items-start gap-3 rounded-2xl p-4">
              <Clock className="mt-0.5 h-5 w-5 text-primary" />
              <span>Mon–Sat: 10:00 – 21:00<br />Sunday: By appointment</span>
            </div>
          </div>

          <Button asChild size="lg" className="mt-6 rounded-full bg-gradient-primary text-primary-foreground shadow-neon">
            <a href={CLINIC.whatsapp} target="_blank" rel="noreferrer">Message on WhatsApp</a>
          </Button>
        </Reveal>
      </div>
    </section>
  );
}
