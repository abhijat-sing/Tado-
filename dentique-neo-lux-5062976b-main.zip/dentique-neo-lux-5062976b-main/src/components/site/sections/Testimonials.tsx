import { Reveal } from "@/components/site/Reveal";
import { Star } from "lucide-react";

const items = [
  {
    n: "Ananya S.",
    r: "I was terrified of implants — DENTIQUE made it painless and quick. My new smile feels completely natural.",
    role: "Implant patient",
  },
  {
    n: "Rohan M.",
    r: "The clinic feels like a luxury spa. Dr. and the team explained every step. Genuinely the best in Lucknow.",
    role: "Cosmetic patient",
  },
  {
    n: "Priya K.",
    r: "Whitening results were stunning. The futuristic vibe is icing on the cake — I left feeling cared for.",
    role: "Whitening patient",
  },
  {
    n: "Vikram T.",
    r: "Brought my whole family for check-ups. Modern, clean, and the kids loved it. Highly recommend.",
    role: "Family check-ups",
  },
];

export function Testimonials() {
  return (
    <section className="relative py-24">
      <div className="blob -left-20 top-10 h-72 w-72 bg-accent/40" />
      <div className="mx-auto max-w-7xl px-4">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">Patient Stories</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Loved by Lucknow's <span className="text-gradient">smiles</span>
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {items.map((t, i) => (
            <Reveal key={t.n} delay={i * 0.05}>
              <div className="tilt-card glass relative h-full rounded-3xl p-6 shadow-soft">
                <div className="flex gap-0.5 text-primary">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="mt-3 text-sm">"{t.r}"</p>
                <div className="mt-5 flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground font-semibold">
                    {t.n[0]}
                  </div>
                  <div>
                    <div className="text-sm font-semibold">{t.n}</div>
                    <div className="text-[11px] text-muted-foreground">{t.role}</div>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
