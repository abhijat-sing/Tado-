import { Reveal } from "@/components/site/Reveal";
import { BeforeAfterSlider } from "@/components/site/BeforeAfterSlider";
import b1 from "@/assets/before-1.jpg";
import a1 from "@/assets/after-1.jpg";
import b2 from "@/assets/before-2.jpg";
import a2 from "@/assets/after-2.jpg";

export function Transformations() {
  return (
    <section id="gallery" className="relative py-24">
      <div className="mx-auto max-w-7xl px-4">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">Smile Gallery</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Real <span className="text-gradient">transformations</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Drag the slider to see the before & after of our cosmetic and implant patients.
          </p>
        </Reveal>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <Reveal>
            <BeforeAfterSlider before={b1} after={a1} alt="Whitening transformation" />
            <p className="mt-3 text-sm text-muted-foreground">Teeth Whitening + Bonding</p>
          </Reveal>
          <Reveal delay={0.1}>
            <BeforeAfterSlider before={b2} after={a2} alt="Smile makeover" />
            <p className="mt-3 text-sm text-muted-foreground">Smile Makeover with Veneers</p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
