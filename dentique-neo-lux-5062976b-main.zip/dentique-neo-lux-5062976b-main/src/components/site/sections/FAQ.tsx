import { Reveal } from "@/components/site/Reveal";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "Are dental implants painful?",
    a: "Implants are placed under modern local anesthesia and most patients feel no pain — only mild pressure. Recovery is gentle and we provide a complete care plan.",
  },
  {
    q: "How long does teeth whitening last?",
    a: "Our LED whitening typically lasts 12–18 months depending on diet and oral hygiene. We offer touch-up kits to keep your smile bright.",
  },
  {
    q: "Do you offer same-day implants?",
    a: "Yes — eligible patients can receive immediate-load implants in a single visit, after a CBCT-guided assessment.",
  },
  {
    q: "Where is DENTIQUE located in Lucknow?",
    a: "We are at Sector 2, Kalandi Park, Vrindavan Yojna-2, behind SKD School. Free patient parking is available.",
  },
  {
    q: "Do you accept walk-ins?",
    a: "We do accept walk-ins, but we strongly recommend booking — it helps us reserve dedicated time for your treatment.",
  },
];

export function FAQ() {
  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-3xl px-4">
        <Reveal className="text-center">
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">FAQ</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Questions, <span className="text-gradient">answered</span>
          </h2>
        </Reveal>

        <Reveal className="mt-10" delay={0.1}>
          <Accordion type="single" collapsible className="glass rounded-3xl p-2">
            {faqs.map((f, i) => (
              <AccordionItem key={f.q} value={`i-${i}`} className="border-b border-border/60 last:border-b-0">
                <AccordionTrigger className="px-4 text-left">{f.q}</AccordionTrigger>
                <AccordionContent className="px-4 text-muted-foreground">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}
