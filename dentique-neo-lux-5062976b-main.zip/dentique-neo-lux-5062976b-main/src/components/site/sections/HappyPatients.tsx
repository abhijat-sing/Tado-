import { Reveal } from "@/components/site/Reveal";
import { motion } from "framer-motion";
import p1 from "@/assets/clinic-photo-1.jpg";
import p2 from "@/assets/clinic-photo-2.jpg";
import p3 from "@/assets/clinic-photo-3.jpg";
import p4 from "@/assets/clinic-photo-4.jpg";

const photos = [
  { src: p4, caption: "Happy young patient" },
  { src: p3, caption: "Smiles after treatment" },
  { src: p1, caption: "Thumbs-up from our youngest" },
  { src: p2, caption: "Gentle care for kids" },
];

export function HappyPatients() {
  return (
    <section className="relative py-24">
      <div className="blob -left-20 top-20 h-72 w-72 bg-primary/25" />
      <div className="blob -right-10 bottom-10 h-72 w-72 bg-accent/30" />
      <div className="relative mx-auto max-w-7xl px-4">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">Happy Patients</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Real moments at <span className="text-gradient">DENTIQUE</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            A glimpse inside our clinic — calm, friendly and made to put you at ease.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {photos.map((p, i) => (
            <Reveal key={i} delay={i * 0.06}>
              <motion.div
                whileHover={{ y: -6 }}
                className="group relative aspect-[4/5] overflow-hidden rounded-3xl glass shadow-soft"
              >
                <img
                  src={p.src}
                  alt={p.caption}
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/85 via-background/10 to-transparent" />
                <div className="absolute inset-x-3 bottom-3 glass rounded-2xl p-3">
                  <div className="text-xs font-medium">{p.caption}</div>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
