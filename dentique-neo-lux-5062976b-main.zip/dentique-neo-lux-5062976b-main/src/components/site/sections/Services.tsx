import { Link } from "@tanstack/react-router";
import {
  Smile,
  Sparkles,
  Stethoscope,
  Gem,
  Wand2,
  ShieldCheck,
} from "lucide-react";
import { Reveal } from "@/components/site/Reveal";

const items = [
  { icon: Gem, title: "Dental Implants", desc: "Titanium-grade, same-day implants with lifelike crowns." },
  { icon: Sparkles, title: "Teeth Whitening", desc: "Advanced LED whitening — brighter smiles in one visit." },
  { icon: Wand2, title: "Cosmetic Dentistry", desc: "Veneers, contouring & smile design tailored to you." },
  { icon: Smile, title: "Smile Makeovers", desc: "Full-mouth aesthetic transformations, planned digitally." },
  { icon: Stethoscope, title: "Dental Check-ups", desc: "Comprehensive screenings with intra-oral imaging." },
  { icon: ShieldCheck, title: "Dental Bonding", desc: "Repair chips and gaps with seamless composite artistry." },
];

export function Services() {
  return (
    <section id="services" className="relative py-24">
      <div className="blob -left-24 top-10 h-72 w-72 bg-primary/25" />
      <div className="blob -right-10 bottom-10 h-72 w-72 bg-accent/30" />
      <div className="relative mx-auto max-w-7xl px-4">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">Our Services</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Premium care, <span className="text-gradient">crafted around you</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            From routine check-ups to full smile design, every treatment is delivered with precision technology and a soft, human touch.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.05}>
              <Link
                to="/services"
                className="tilt-card group relative block h-full overflow-hidden rounded-3xl glass p-6 shadow-soft"
              >
                <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gradient-primary opacity-0 blur-3xl transition group-hover:opacity-50" />
                <div className="relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-neon">
                  <s.icon className="h-5 w-5" />
                </div>
                <h3 className="relative mt-5 font-display text-xl font-semibold">
                  {s.title}
                </h3>
                <p className="relative mt-2 text-sm text-muted-foreground">{s.desc}</p>
                <div className="relative mt-6 inline-flex items-center text-sm font-medium text-primary">
                  Learn more →
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
