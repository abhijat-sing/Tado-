import { Reveal } from "@/components/site/Reveal";
import { Counter } from "@/components/site/Counter";
import clinic from "@/assets/clinic-photo-3.jpg";
import { CheckCircle2 } from "lucide-react";

const timeline = [
  { y: "2009", t: "Founded", d: "DENTIQUE opens its first chair in Lucknow." },
  { y: "2014", t: "Implant Center", d: "Dedicated implant suite with CBCT imaging." },
  { y: "2019", t: "Digital Smile Design", d: "AI-assisted treatment planning launched." },
  { y: "2025", t: "Futuristic Studio", d: "Re-imagined experience in Vrindavan Yojna." },
];

export function About() {
  return (
    <section id="about" className="relative py-24">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 md:grid-cols-2 md:items-center">
        <Reveal className="relative">
          <div className="absolute -inset-4 rounded-[2rem] bg-gradient-primary opacity-20 blur-3xl" />
          <div className="relative overflow-hidden rounded-[2rem] glass shadow-elegant">
            <img src={clinic} alt="Modern DENTIQUE clinic interior" className="h-full w-full object-cover" loading="lazy" />
          </div>
          <div className="absolute -bottom-6 -right-2 hidden glass rounded-2xl p-4 shadow-soft md:block">
            <div className="text-xs text-muted-foreground">Trusted by</div>
            <div className="font-display text-2xl font-semibold text-gradient">
              <Counter to={12000} />+
            </div>
            <div className="text-xs">Smiles transformed</div>
          </div>
        </Reveal>

        <div>
          <Reveal>
            <span className="rounded-full border border-border glass px-3 py-1 text-xs">About DENTIQUE</span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
              Advanced technology, <span className="text-gradient">personalized care</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              At DENTIQUE Dental Clinic & Implant Center, we blend clinical excellence with a modern, calming experience. Our team is led by specialists in implantology and cosmetic dentistry — committed to natural-looking results that last.
            </p>
          </Reveal>

          <Reveal className="mt-6 grid grid-cols-2 gap-3" delay={0.1}>
            {[
              "ISO sterilization protocol",
              "Digital X-rays & CBCT",
              "Pain-free local anesthesia",
              "Same-day implants available",
            ].map((p) => (
              <div key={p} className="flex items-start gap-2 rounded-2xl glass p-3 text-sm">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-primary" />
                <span>{p}</span>
              </div>
            ))}
          </Reveal>

          <Reveal className="mt-8 space-y-4 border-l border-border pl-5" delay={0.15}>
            {timeline.map((t) => (
              <div key={t.y} className="relative">
                <span className="absolute -left-[26px] top-1.5 h-3 w-3 rounded-full bg-gradient-primary shadow-neon" />
                <div className="text-xs font-semibold text-primary">{t.y}</div>
                <div className="font-medium">{t.t}</div>
                <div className="text-sm text-muted-foreground">{t.d}</div>
              </div>
            ))}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
