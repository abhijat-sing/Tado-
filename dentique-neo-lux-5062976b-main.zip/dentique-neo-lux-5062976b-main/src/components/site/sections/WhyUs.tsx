import { Reveal } from "@/components/site/Reveal";
import { Counter } from "@/components/site/Counter";
import {
  Cpu,
  HeartHandshake,
  GraduationCap,
  Microscope,
  Shield,
  Leaf,
} from "lucide-react";

const points = [
  { icon: Cpu, title: "Advanced Implant Tech", d: "CBCT-guided precision implant surgery." },
  { icon: HeartHandshake, title: "Painless Procedures", d: "Modern anesthesia & calming protocols." },
  { icon: GraduationCap, title: "Expert Dental Team", d: "Specialists in implantology & cosmetics." },
  { icon: Microscope, title: "Modern Equipment", d: "Digital scanners, lasers & loupes." },
  { icon: Shield, title: "Sterile Environment", d: "ISO-grade sterilization at every step." },
  { icon: Leaf, title: "Personalized Care", d: "Treatment plans designed around you." },
];

const stats = [
  { v: 12000, s: "+", l: "Happy patients" },
  { v: 3500, s: "+", l: "Implants placed" },
  { v: 15, s: "+", l: "Years experience" },
  { v: 99, s: "%", l: "Satisfaction" },
];

export function WhyUs() {
  return (
    <section className="section-dark relative overflow-hidden bg-background py-24 text-foreground">
      <div className="absolute inset-0 bg-aurora opacity-30" />
      <div className="blob -left-20 top-20 h-96 w-96 bg-primary/40" />
      <div className="blob -right-20 bottom-10 h-96 w-96 bg-accent/40" />
      <div className="relative mx-auto max-w-7xl px-4">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="rounded-full border border-white/15 glass-dark px-3 py-1 text-xs">Why DENTIQUE</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Care that feels <span className="text-gradient">effortless</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Six reasons families across Lucknow choose DENTIQUE for life-changing dental care.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {points.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.05}>
              <div className="tilt-card glass-dark relative h-full overflow-hidden rounded-3xl p-6">
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-neon">
                  <p.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold">{p.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{p.d}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="relative mt-16 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {stats.map((s) => (
            <div key={s.l} className="glass-dark rounded-3xl p-6 text-center">
              <div className="font-display text-3xl font-semibold text-gradient sm:text-4xl">
                <Counter to={s.v} suffix={s.s} />
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
