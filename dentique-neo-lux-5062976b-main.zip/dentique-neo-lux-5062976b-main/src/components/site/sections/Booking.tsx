import { Reveal } from "@/components/site/Reveal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { CLINIC } from "@/lib/clinic";
import { ArrowRight, ArrowLeft, Check, MessageCircle, Phone } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const steps = ["Service", "Date & Time", "Your Details"] as const;

export function Booking() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    service: CLINIC.services[0],
    date: "",
    time: "",
    name: "",
    phone: "",
    note: "",
  });

  const next = () => setStep((s) => Math.min(steps.length - 1, s + 1));
  const back = () => setStep((s) => Math.max(0, s - 1));

  const submit = () => {
    if (!data.name || !data.phone) {
      toast.error("Please share your name and phone");
      return;
    }
    const text = encodeURIComponent(
      `Hi DENTIQUE, I'd like to book ${data.service} on ${data.date} at ${data.time}.\nName: ${data.name}\nPhone: ${data.phone}\nNote: ${data.note}`,
    );
    window.open(`${CLINIC.whatsapp}?text=${text}`, "_blank");
    toast.success("Opening WhatsApp to confirm your booking");
  };

  return (
    <section id="book" className="relative py-24">
      <div className="absolute inset-0 bg-aurora opacity-25" />
      <div className="blob -left-10 top-10 h-72 w-72 bg-primary/30" />
      <div className="blob -right-10 bottom-10 h-72 w-72 bg-accent/40" />

      <div className="relative mx-auto grid max-w-6xl gap-10 px-4 md:grid-cols-2 md:items-center">
        <Reveal>
          <span className="rounded-full border border-border glass px-3 py-1 text-xs">Booking</span>
          <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl md:text-5xl">
            Reserve your <span className="text-gradient">smile session</span>
          </h2>
          <p className="mt-3 max-w-md text-muted-foreground">
            Pick a treatment, choose a time, and our concierge will confirm your appointment within minutes.
          </p>
          <div className="mt-6 flex flex-col gap-3">
            <a href={CLINIC.whatsapp} target="_blank" rel="noreferrer" className="glass flex items-center gap-3 rounded-2xl p-3 text-sm shadow-soft">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground"><MessageCircle className="h-4 w-4" /></span>
              Quick WhatsApp connect
            </a>
            <a href={`tel:${CLINIC.phoneRaw}`} className="glass flex items-center gap-3 rounded-2xl p-3 text-sm shadow-soft">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground"><Phone className="h-4 w-4" /></span>
              {CLINIC.phone}
            </a>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="glass relative overflow-hidden rounded-[2rem] p-6 shadow-elegant sm:p-8">
            <div className="mb-6 flex items-center gap-2">
              {steps.map((s, i) => (
                <div key={s} className="flex flex-1 items-center gap-2">
                  <div
                    className={`grid h-7 w-7 place-items-center rounded-full text-xs font-semibold ${
                      i <= step ? "bg-gradient-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
                  </div>
                  {i < steps.length - 1 && (
                    <div className={`h-px flex-1 ${i < step ? "bg-gradient-primary" : "bg-border"}`} />
                  )}
                </div>
              ))}
            </div>

            <div className="min-h-[260px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.35 }}
                >
                  {step === 0 && (
                    <div className="grid grid-cols-2 gap-2">
                      {CLINIC.services.map((s) => (
                        <button
                          key={s}
                          onClick={() => setData((d) => ({ ...d, service: s }))}
                          className={`rounded-2xl border p-3 text-left text-sm transition ${
                            data.service === s
                              ? "border-primary bg-gradient-primary text-primary-foreground shadow-neon"
                              : "border-border bg-background/60 hover:border-primary/60"
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  )}
                  {step === 1 && (
                    <div className="grid gap-3">
                      <div>
                        <Label htmlFor="date">Preferred date</Label>
                        <Input id="date" type="date" value={data.date} onChange={(e) => setData((d) => ({ ...d, date: e.target.value }))} />
                      </div>
                      <div>
                        <Label htmlFor="time">Preferred time</Label>
                        <Input id="time" type="time" value={data.time} onChange={(e) => setData((d) => ({ ...d, time: e.target.value }))} />
                      </div>
                    </div>
                  )}
                  {step === 2 && (
                    <div className="grid gap-3">
                      <div>
                        <Label htmlFor="name">Your name</Label>
                        <Input id="name" value={data.name} onChange={(e) => setData((d) => ({ ...d, name: e.target.value }))} placeholder="Full name" />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input id="phone" value={data.phone} onChange={(e) => setData((d) => ({ ...d, phone: e.target.value }))} placeholder="+91 …" />
                      </div>
                      <div>
                        <Label htmlFor="note">Note (optional)</Label>
                        <Input id="note" value={data.note} onChange={(e) => setData((d) => ({ ...d, note: e.target.value }))} placeholder="Anything to share?" />
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="mt-6 flex justify-between">
              <Button variant="ghost" onClick={back} disabled={step === 0} className="rounded-full">
                <ArrowLeft className="mr-1 h-4 w-4" /> Back
              </Button>
              {step < steps.length - 1 ? (
                <Button onClick={next} className="rounded-full bg-gradient-primary text-primary-foreground shadow-neon">
                  Next <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              ) : (
                <Button onClick={submit} className="rounded-full bg-gradient-primary text-primary-foreground shadow-neon">
                  Confirm via WhatsApp
                </Button>
              )}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
