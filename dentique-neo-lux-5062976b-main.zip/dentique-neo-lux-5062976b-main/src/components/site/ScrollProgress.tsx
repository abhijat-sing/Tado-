import { motion, useScroll, useSpring } from "framer-motion";

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const x = useSpring(scrollYProgress, { stiffness: 120, damping: 20, mass: 0.2 });
  return (
    <motion.div
      style={{ scaleX: x }}
      className="fixed left-0 right-0 top-0 z-[60] h-0.5 origin-left bg-gradient-primary"
      aria-hidden
    />
  );
}
