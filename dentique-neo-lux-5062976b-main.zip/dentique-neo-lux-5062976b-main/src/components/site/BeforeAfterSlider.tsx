import { useRef, useState } from "react";

export function BeforeAfterSlider({
  before,
  after,
  alt,
}: {
  before: string;
  after: string;
  alt: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(50);

  const onMove = (clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.max(0, Math.min(100, x)));
  };

  return (
    <div
      ref={ref}
      className="group relative aspect-square w-full select-none overflow-hidden rounded-3xl border border-border shadow-elegant"
      onMouseMove={(e) => e.buttons === 1 && onMove(e.clientX)}
      onTouchMove={(e) => onMove(e.touches[0].clientX)}
      onClick={(e) => onMove(e.clientX)}
    >
      <img src={after} alt={`${alt} after`} className="absolute inset-0 h-full w-full object-cover" loading="lazy" />
      <div
        className="absolute inset-y-0 left-0 overflow-hidden"
        style={{ width: `${pos}%` }}
      >
        <img
          src={before}
          alt={`${alt} before`}
          className="h-full w-full object-cover"
          style={{ width: ref.current?.clientWidth ?? "100%", maxWidth: "none" }}
          loading="lazy"
        />
      </div>
      <div
        className="absolute inset-y-0 w-0.5 bg-white/90 shadow-neon"
        style={{ left: `${pos}%` }}
      >
        <div className="absolute left-1/2 top-1/2 grid h-10 w-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white text-primary shadow-neon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M9 6l-6 6 6 6M15 6l6 6-6 6" />
          </svg>
        </div>
      </div>
      <div className="pointer-events-none absolute left-3 top-3 rounded-full glass px-3 py-1 text-xs font-medium">Before</div>
      <div className="pointer-events-none absolute right-3 top-3 rounded-full bg-gradient-primary px-3 py-1 text-xs font-medium text-primary-foreground">After</div>
    </div>
  );
}
