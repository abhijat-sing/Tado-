import { createFileRoute } from "@tanstack/react-router";
import { About } from "@/components/site/sections/About";
import { WhyUs } from "@/components/site/sections/WhyUs";
import { Testimonials } from "@/components/site/sections/Testimonials";
import { Reveal } from "@/components/site/Reveal";
import doctor from "@/assets/doctor-portrait.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About DENTIQUE — Best Dentist in Vrindavan Yojna, Lucknow" },
      { name: "description", content: "Meet the DENTIQUE team — specialists in implantology and cosmetic dentistry in Lucknow. Advanced technology with personalized care." },
      { property: "og:title", content: "About DENTIQUE — Best Dentist in Lucknow" },
      { property: "og:description", content: "Specialists in implants & cosmetic dentistry serving Lucknow since 2009." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <section className="relative pt-36 pb-12">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 md:grid-cols-2 md:items-center">
          <Reveal>
            <span className="rounded-full border border-border glass px-3 py-1 text-xs">About</span>
            <h1 className="mt-4 font-display text-4xl font-semibold sm:text-5xl md:text-6xl">
              A studio for <span className="text-gradient">confident smiles</span>
            </h1>
            <p className="mt-4 max-w-lg text-muted-foreground">
              DENTIQUE was founded with one mission — make world-class dentistry feel calm, beautiful and accessible to every family in Lucknow.
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="relative aspect-[4/5] max-w-sm overflow-hidden rounded-[2rem] glass shadow-elegant md:ml-auto">
              <img src={doctor} alt="DENTIQUE lead dentist" className="h-full w-full object-cover" loading="lazy" />
            </div>
          </Reveal>
        </div>
      </section>
      <About />
      <WhyUs />
      <Testimonials />
    </>
  );
}
