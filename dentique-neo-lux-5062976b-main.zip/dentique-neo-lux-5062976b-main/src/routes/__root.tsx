import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { ScrollProgress } from "@/components/site/ScrollProgress";
import { CursorGlow } from "@/components/site/CursorGlow";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";
import { Toaster } from "@/components/ui/sonner";
import { CLINIC } from "@/lib/clinic";

function NotFoundComponent() {
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-semibold text-gradient">404</h1>
        <p className="mt-4 text-muted-foreground">This page drifted off the smile chart.</p>
        <Link to="/" className="mt-6 inline-flex rounded-full bg-gradient-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-neon">
          Go home
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-2xl font-semibold">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Please try again or head back home.</p>
        <div className="mt-6 flex justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="rounded-full bg-gradient-primary px-5 py-2.5 text-sm font-medium text-primary-foreground">Try again</button>
          <a href="/" className="rounded-full border border-border bg-background px-5 py-2.5 text-sm font-medium">Go home</a>
        </div>
      </div>
    </div>
  );
}

const jsonLd = JSON.stringify({
  "@context": "https://schema.org",
  "@type": "Dentist",
  name: CLINIC.name,
  image: "/og-cover.jpg",
  telephone: CLINIC.phoneRaw,
  priceRange: "$$",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Behind SKD School, Vrindavan Yojna-2, Sector 2, Kalandi Park",
    addressLocality: "Lucknow",
    addressRegion: "Uttar Pradesh",
    postalCode: "226014",
    addressCountry: "IN",
  },
  areaServed: "Lucknow",
  openingHours: "Mo-Sa 10:00-21:00",
  url: "https://dentique.in/",
  sameAs: [],
});

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "DENTIQUE — Luxury Dental Clinic & Implant Center, Lucknow" },
      { name: "description", content: "Premium dental implants, cosmetic dentistry, teeth whitening and smile makeovers in Vrindavan Yojna, Lucknow." },
      { name: "author", content: "DENTIQUE" },
      { name: "theme-color", content: "#8B5CF6" },
      { property: "og:title", content: "DENTIQUE — Luxury Dental Clinic & Implant Center" },
      { property: "og:description", content: "Advanced dental care with futuristic precision in Lucknow." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" },
      { rel: "stylesheet", href: "https://api.fontshare.com/v2/css?f[]=clash-display@500,600,700&display=swap" },
    ],
    scripts: [
      { type: "application/ld+json", children: jsonLd },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <SmoothScroll />
      <ScrollProgress />
      <CursorGlow />
      <Navbar />
      <main className="relative">
        <Outlet />
      </main>
      <Footer />
      <WhatsAppFab />
      <Toaster />
    </QueryClientProvider>
  );
}
