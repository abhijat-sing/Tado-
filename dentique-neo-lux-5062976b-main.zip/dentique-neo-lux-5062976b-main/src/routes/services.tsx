import { createFileRoute } from "@tanstack/react-router";
import { Services } from "@/components/site/sections/Services";
import { Booking } from "@/components/site/sections/Booking";
import { FAQ } from "@/components/site/sections/FAQ";
import { Reveal } from "@/components/site/Reveal";
import implant from "@/assets/implant-closeup.jpg";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Dental Implants, Whitening & Cosmetic Dentistry in Lucknow | DENTIQUE" },
      { name: "description", content: "Explore DENTIQUE's services: dental implants, teeth whitening, cosmetic dentistry, smile makeovers, dental check-ups and bonding in Lucknow." },
      { property: "og:title", content: "Dental Services in Lucknow — DENTIQUE" },
      { property: "og:description", content: "Premium dental treatments with futuristic precision." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <>
      <section className="relative pt-36 pb-12">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="blob -left-10 top-20 h-72 w-72 bg-primary/30" />
        <div className="blob -right-10 top-10 h-72 w-72 bg-accent/40" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 md:grid-cols-2 md:items-center">
          <Reveal>
            <span className="rounded-full border border-border glass px-3 py-1 text-xs">Services</span>
            <h1 className="mt-4 font-display text-4xl font-semibold sm:text-5xl md:text-6xl">
              Treatments <span className="text-gradient">designed for you</span>
            </h1>
            <p className="mt-4 max-w-lg text-muted-foreground">
              Each service is delivered using the latest digital workflows, sterile protocols and a personal touch you'll feel from the moment you arrive.
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="relative aspect-[4/3] overflow-hidden rounded-[2rem] glass shadow-elegant">
              <img src={implant} alt="Dental implant close-up" className="h-full w-full object-cover" loading="lazy" />
            </div>
          </Reveal>
        </div>
      </section>
      <Services />
      <Booking />
      <FAQ />
    </>
  );
}
