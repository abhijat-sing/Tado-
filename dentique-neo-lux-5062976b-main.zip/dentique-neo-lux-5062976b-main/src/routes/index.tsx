import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/site/sections/Hero";
import { Services } from "@/components/site/sections/Services";
import { About } from "@/components/site/sections/About";
import { WhyUs } from "@/components/site/sections/WhyUs";
import { Transformations } from "@/components/site/sections/Transformations";
import { HappyPatients } from "@/components/site/sections/HappyPatients";
import { Testimonials } from "@/components/site/sections/Testimonials";
import { Booking } from "@/components/site/sections/Booking";
import { ContactBlock } from "@/components/site/sections/ContactBlock";
import { FAQ } from "@/components/site/sections/FAQ";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DENTIQUE — Best Dental Clinic in Lucknow | Implants & Cosmetic Dentistry" },
      { name: "description", content: "Luxury dental care in Lucknow. Dental implants, teeth whitening, cosmetic dentistry & smile makeovers in Vrindavan Yojna. Book your appointment." },
      { property: "og:title", content: "DENTIQUE — Luxury Dental Clinic in Lucknow" },
      { property: "og:description", content: "Advanced implants & cosmetic dentistry in Vrindavan Yojna, Lucknow." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <Services />
      <About />
      <WhyUs />
      <Transformations />
      <HappyPatients />
      <Testimonials />
      <Booking />
      <ContactBlock />
      <FAQ />
    </>
  );
}
