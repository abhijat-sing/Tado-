import { createFileRoute } from "@tanstack/react-router";
import { Transformations } from "@/components/site/sections/Transformations";
import { Testimonials } from "@/components/site/sections/Testimonials";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Smile Gallery — Before & After | DENTIQUE Lucknow" },
      { name: "description", content: "Real before-and-after smile transformations from DENTIQUE patients in Lucknow — implants, whitening and smile makeovers." },
      { property: "og:title", content: "Smile Gallery — DENTIQUE Lucknow" },
      { property: "og:description", content: "Drag the slider to see real smile transformations." },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  return (
    <>
      <section className="relative pt-36 pb-4">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative mx-auto max-w-3xl px-4 text-center">
          <Reveal>
            <span className="rounded-full border border-border glass px-3 py-1 text-xs">Smile Gallery</span>
            <h1 className="mt-4 font-display text-4xl font-semibold sm:text-5xl md:text-6xl">
              See the <span className="text-gradient">transformation</span>
            </h1>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Every smile here was crafted by our team — drag the slider to reveal the after.
            </p>
          </Reveal>
        </div>
      </section>
      <Transformations />
      <Testimonials />
    </>
  );
}
