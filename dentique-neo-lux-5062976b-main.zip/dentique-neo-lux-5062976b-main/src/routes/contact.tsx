import { createFileRoute } from "@tanstack/react-router";
import { Booking } from "@/components/site/sections/Booking";
import { ContactBlock } from "@/components/site/sections/ContactBlock";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Book — DENTIQUE Dental Clinic, Lucknow" },
      { name: "description", content: "Book your dental appointment at DENTIQUE in Vrindavan Yojna, Lucknow. Call +91 99757 64714 or message on WhatsApp." },
      { property: "og:title", content: "Book your appointment — DENTIQUE Lucknow" },
      { property: "og:description", content: "Call, WhatsApp or fill the form to reserve your visit." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <>
      <section className="relative pt-36 pb-4">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative mx-auto max-w-3xl px-4 text-center">
          <Reveal>
            <span className="rounded-full border border-border glass px-3 py-1 text-xs">Contact</span>
            <h1 className="mt-4 font-display text-4xl font-semibold sm:text-5xl md:text-6xl">
              Let's plan your <span className="text-gradient">smile</span>
            </h1>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Tell us a little about you and our concierge will confirm your appointment shortly.
            </p>
          </Reveal>
        </div>
      </section>
      <Booking />
      <ContactBlock />
    </>
  );
}
